import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { BookProvider } from './src/contexts/BookContext';

import ListScreen from './src/screens/ListScreen';
import FormScreen from './src/screens/FormScreen';
import DetailScreen from './src/screens/DetailScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <BookProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="List">
          <Stack.Screen name="List" component={ListScreen} options={{ title: 'Andre´s library' }} />
          <Stack.Screen name="Form" component={FormScreen} options={{ title: 'Cadastrar/Editar' }} />
          <Stack.Screen name="Details" component={DetailScreen} options={{ title: 'Detalhes' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </BookProvider>
  );
}