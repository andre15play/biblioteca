import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Cria o contexto para espalhar os dados pelo app
export const BookContext = createContext();

export const BookProvider = ({ children }) => {
  const [books, setBooks] = useState([]);

  // Quando o app abre, ele busca os livros salvos
  useEffect(() => {
    const loadBooks = async () => {
      const storedBooks = await AsyncStorage.getItem('@livros');
      if (storedBooks) setBooks(JSON.parse(storedBooks));
    };
    loadBooks();
  }, []);

  // Função para salvar a lista atualizada no celular
  const saveBooks = async (newBooks) => {
    setBooks(newBooks);
    await AsyncStorage.setItem('@livros', JSON.stringify(newBooks));
  };

  const addBook = (livro) => {
    const newBook = { ...livro, id: Date.now().toString() };
    saveBooks([...books, newBook]);
  };

  const updateBook = (updatedBook) => {
    const updatedBooks = books.map(book => book.id === updatedBook.id ? updatedBook : book);
    saveBooks(updatedBooks);
  };

  const removeBook = (id) => {
    const updatedBooks = books.filter(book => book.id !== id);
    saveBooks(updatedBooks);
  };

  return (
    <BookContext.Provider value={{ books, addBook, updateBook, removeBook }}>
      {children}
    </BookContext.Provider>
  );
};