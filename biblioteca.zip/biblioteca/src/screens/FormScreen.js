import React, { useState, useContext, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Switch } from 'react-native';
import { BookContext } from '../contexts/BookContext';

export default function FormScreen({ route, navigation }) {
  const { addBook, updateBook } = useContext(BookContext);
  // Se viemos da tela de edição, recebemos o livro aqui
  const bookToEdit = route.params?.book;

  const [titulo, setTitulo] = useState('');
  const [autor, setAutor] = useState('');
  const [anoPublicacao, setAnoPublicacao] = useState('');
  const [disponivel, setDisponivel] = useState(true);

  // Preenche os campos automaticamente se for modo "Edição"
  useEffect(() => {
    if (bookToEdit) {
      setTitulo(bookToEdit.titulo);
      setAutor(bookToEdit.autor);
      setAnoPublicacao(bookToEdit.anoPublicacao);
      setDisponivel(bookToEdit.disponivel);
    }
  }, [bookToEdit]);

  const handleSave = () => {
    if (!titulo || !autor || !anoPublicacao) {
      alert('Por favor, preencha todos os campos!');
      return;
    }

    const bookData = { id: bookToEdit ? bookToEdit.id : null, titulo, autor, anoPublicacao, disponivel };

    if (bookToEdit) {
      updateBook(bookData);
    } else {
      addBook(bookData);
    }
    navigation.goBack(); // Volta pra tela de lista
  };

  return (
    <View style={styles.container}>
      <Text>Título:</Text>
      <TextInput style={styles.input} value={titulo} onChangeText={setTitulo} />
      
      <Text>Autor:</Text>
      <TextInput style={styles.input} value={autor} onChangeText={setAutor} />

      <Text>Ano de Publicação:</Text>
      <TextInput style={styles.input} value={anoPublicacao} onChangeText={setAnoPublicacao} keyboardType="numeric" />

      <View style={styles.switchContainer}>
        <Text>Disponível na Biblioteca?</Text>
        <Switch value={disponivel} onValueChange={setDisponivel} />
      </View>

      <Button title="Salvar Livro" onPress={handleSave} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginVertical: 8, borderRadius: 4 },
  switchContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginVertical: 16 }
});