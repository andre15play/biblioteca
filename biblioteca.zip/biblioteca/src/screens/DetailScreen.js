import React, { useContext, useState } from 'react';
import { View, Text, StyleSheet, Switch } from 'react-native';
import { BookContext } from '../contexts/BookContext';

export default function DetailScreen({ route }) {
  const { updateBook } = useContext(BookContext);
  // Pega as informações do livro que o usuário clicou
  const [book, setBook] = useState(route.params.book);

  const toggleDisponibilidade = () => {
    const updatedBook = { ...book, disponivel: !book.disponivel };
    updateBook(updatedBook); // Atualiza no banco de dados local
    setBook(updatedBook); // Atualiza na tela
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{book.titulo}</Text>
      <Text style={styles.text}>Autor: {book.autor}</Text>
      <Text style={styles.text}>Ano de Publicação: {book.anoPublicacao}</Text>
      
      <View style={styles.statusContainer}>
        <Text style={styles.text}>Status: {book.disponivel ? 'Disponível' : 'Emprestado'}</Text>
        <Switch value={book.disponivel} onValueChange={toggleDisponibilidade} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 16 },
  text: { fontSize: 18, marginBottom: 8 },
  statusContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 20, padding: 10, backgroundColor: '#e6e6e6', borderRadius: 8 }
});