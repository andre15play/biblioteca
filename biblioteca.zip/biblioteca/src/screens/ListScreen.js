import React, { useContext } from 'react';
import { View, Text, FlatList, Button, StyleSheet } from 'react-native';
import { BookContext } from '../contexts/BookContext';

export default function ListScreen({ navigation }) {
  // Pega os livros e a função de remover do Context
  const { books, removeBook } = useContext(BookContext);

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.info}>
        <Text style={styles.title}>{item.titulo}</Text>
        <Text>Autor: {item.autor}</Text>
      </View>
      <View style={styles.actions}>
        <Button title="Ver" onPress={() => navigation.navigate('Details', { book: item })} />
        <Button title="Editar" color="orange" onPress={() => navigation.navigate('Form', { book: item })} />
        <Button title="Apagar" color="red" onPress={() => removeBook(item.id)} />
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={books}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListEmptyComponent={<Text style={styles.empty}>Nenhum livro na biblioteca.</Text>}
      />
      <Button title="Cadastrar Novo Livro" onPress={() => navigation.navigate('Form')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  card: { padding: 12, marginVertical: 8, backgroundColor: '#f0f0f0', borderRadius: 8 },
  title: { fontSize: 18, fontWeight: 'bold' },
  info: { marginBottom: 10 },
  actions: { flexDirection: 'row', justifyContent: 'space-between' },
  empty: { textAlign: 'center', marginTop: 50, fontSize: 16 }
});